## Node.js-mini-projects


 Note App : This is simple Note app. You can add,delete,read,list a note(s).

 Weather App : Given an address or zipcode, returns current temperatures for the location.
